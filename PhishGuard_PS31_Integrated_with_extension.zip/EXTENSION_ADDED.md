# PhishGuard AI Extension Added

A new `extension/` folder has been added to this project.

The extension uses the existing FastAPI endpoint:
`POST /api/v1/analyze`

Before production/demo on another machine, update:
`extension/background.js` -> `API_BASE`

Default:
`http://localhost:8000/api/v1`

See `extension/README.md` for installation instructions.
