const API_BASE = "http://localhost:8000/api/v1";

// Change API_BASE to your deployed backend URL before using the extension
// outside your local development machine.

async function analyzeUrl(url) {
  if (!url || /^(chrome|edge|about|brave|opera|file):/i.test(url)) {
    return null;
  }

  try {
    const response = await fetch(`${API_BASE}/analyze`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url })
    });

    if (!response.ok) {
      throw new Error(`API returned ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("PhishGuard API error:", error);
    return {
      error: true,
      message: "Unable to reach PhishGuard backend."
    };
  }
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "loading" || !tab.url) return;

  const url = tab.url;

  if (/^(chrome|edge|about|brave|opera|file):/i.test(url)) return;

  await chrome.storage.local.set({
    [`scan_${tabId}`]: {
      status: "scanning",
      url,
      timestamp: Date.now()
    }
  });

  const result = await analyzeUrl(url);

  await chrome.storage.local.set({
    [`scan_${tabId}`]: {
      status: result?.error ? "error" : "complete",
      url,
      result,
      timestamp: Date.now()
    }
  });

  // Tell the content script to display a warning when appropriate.
  if (result && !result.error) {
    chrome.tabs.sendMessage(tabId, {
      type: "PHISHGUARD_RESULT",
      result
    }).catch(() => {});
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.remove(`scan_${tabId}`);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "SCAN_URL") {
    analyzeUrl(message.url).then(result => {
      sendResponse(result);
    });
    return true;
  }
});