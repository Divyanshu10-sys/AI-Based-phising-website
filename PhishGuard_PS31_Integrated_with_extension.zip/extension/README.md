# PhishGuard AI Browser Extension

This folder contains a Chrome/Edge Manifest V3 extension for PhishGuard AI.

## Features

- Automatically reads the active tab URL.
- Sends the URL to the existing PhishGuard FastAPI `/api/v1/analyze` endpoint.
- Displays Safe / Suspicious / High Risk results.
- Displays risk score and key detection factors.
- Automatically scans page navigation in the background.
- Shows an in-page warning for suspicious/high-risk pages.
- Provides Go Back and Continue Anyway actions.

## Setup

1. Start the PhishGuard FastAPI backend.
2. Open `background.js`.
3. Change `API_BASE` if your backend is not running at:
   `http://localhost:8000/api/v1`
4. In Chrome or Edge open the Extensions page.
5. Enable Developer Mode.
6. Choose **Load unpacked**.
7. Select this `extension` folder.

## Important production note

For deployment to other computers, replace the localhost API URL with your HTTPS cloud API URL and configure the backend CORS policy appropriately.

The extension intentionally does not include the ML model itself. It reuses the existing PhishGuard backend so there is one detection engine for both the website and extension.
