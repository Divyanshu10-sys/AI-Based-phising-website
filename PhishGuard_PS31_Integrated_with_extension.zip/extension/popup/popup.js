function getValue(obj, keys, fallback = null) {
  for (const key of keys) {
    if (obj && obj[key] !== undefined && obj[key] !== null) return obj[key];
  }
  return fallback;
}

function normalizeVerdict(result) {
  const raw = String(
    getValue(result, ["verdict", "classification", "label"], "")
  ).toLowerCase();

  if (raw.includes("high") || raw.includes("phish") || raw.includes("malicious")) return "high";
  if (raw.includes("suspicious") || raw.includes("medium") || raw.includes("warning")) return "suspicious";
  return "safe";
}

function formatValue(value) {
  if (value === true) return "Valid / Yes";
  if (value === false) return "No / Invalid";
  if (value === null || value === undefined || value === "") return "N/A";
  return String(value);
}

function renderFactors(result) {
  const features = result?.features || {};
  const factors = [
    ["Domain Age", getValue(result, ["domain_age_days"], getValue(features, ["domain_age_days", "domainAgeDays"]))],
    ["SSL / HTTPS", getValue(result, ["ssl_valid"], getValue(features, ["ssl_valid", "sslValid", "https"]))],
    ["ML Probability", getValue(result, ["ml_probability", "mlProbability"], getValue(features, ["ml_probability", "mlProbability"]))],
    ["Threat Intel", getValue(result, ["blacklisted", "is_blacklisted", "blacklist"], getValue(features, ["blacklisted"]))]
  ];

  const container = document.getElementById("factors");
  container.innerHTML = "";

  for (const [name, value] of factors) {
    const row = document.createElement("div");
    row.className = "factor";
    row.innerHTML = `
      <span class="factor-name">${name}</span>
      <span class="factor-value">${formatValue(value)}</span>
    `;
    container.appendChild(row);
  }
}

async function scanCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab?.url) return;

  document.getElementById("current-url").textContent = tab.url;

  const stored = await chrome.storage.local.get(`scan_${tab.id}`);
  const scan = stored[`scan_${tab.id}`];

  if (scan?.result && scan.url === tab.url) {
    renderResult(scan.result, scan.timestamp);
    return;
  }

  document.getElementById("status-card").className = "status-card scanning";
  document.getElementById("status-icon").textContent = "⏳";
  document.getElementById("verdict").textContent = "Scanning...";
  document.getElementById("score").textContent = "Analyzing current website";
  document.getElementById("factors").innerHTML = "";

  chrome.runtime.sendMessage({ type: "SCAN_URL", url: tab.url }, (result) => {
    if (chrome.runtime.lastError || !result) {
      renderError("Could not connect to the PhishGuard backend.");
      return;
    }

    renderResult(result, Date.now());
  });
}

function renderResult(result, timestamp) {
  if (result.error) {
    renderError(result.message || "Backend error.");
    return;
  }

  const verdict = normalizeVerdict(result);
  const score = getValue(result, ["risk_score", "riskScore", "score"], "N/A");

  const card = document.getElementById("status-card");
  card.className = `status-card ${verdict}`;

  document.getElementById("status-icon").textContent =
    verdict === "high" ? "🔴" : verdict === "suspicious" ? "🟡" : "🟢";

  document.getElementById("verdict").textContent =
    verdict === "high" ? "PHISHING / HIGH RISK" :
    verdict === "suspicious" ? "SUSPICIOUS" : "SAFE";

  document.getElementById("score").textContent = `Risk Score: ${score}/100`;

  renderFactors(result);

  document.getElementById("message").textContent =
    verdict === "high"
      ? "Avoid entering passwords, OTPs, financial details, or other sensitive information."
      : verdict === "suspicious"
      ? "Proceed carefully and verify the website before sharing sensitive information."
      : "No major phishing indicators were detected by the current analysis.";

  document.getElementById("last-scanned").textContent =
    `Scanned ${new Date(timestamp || Date.now()).toLocaleTimeString()}`;
}

function renderError(message) {
  const card = document.getElementById("status-card");
  card.className = "status-card error";
  document.getElementById("status-icon").textContent = "⚠️";
  document.getElementById("verdict").textContent = "SCAN UNAVAILABLE";
  document.getElementById("score").textContent = message;
  document.getElementById("factors").innerHTML = "";
  document.getElementById("message").textContent =
    "Make sure your FastAPI backend is running and the API URL in background.js is correct.";
}

document.getElementById("refresh").addEventListener("click", scanCurrentTab);
scanCurrentTab();