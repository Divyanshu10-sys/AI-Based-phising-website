(() => {
  let warningShown = false;

  function getValue(obj, keys, fallback = null) {
    for (const key of keys) {
      if (obj && obj[key] !== undefined && obj[key] !== null) return obj[key];
    }
    return fallback;
  }

  function normalizeVerdict(result) {
    const raw = String(
      getValue(result, ["verdict", "classification", "label"], "")
    ).toLowerCase();

    if (raw.includes("high") || raw.includes("phish") || raw.includes("malicious")) {
      return "high";
    }
    if (raw.includes("suspicious") || raw.includes("medium") || raw.includes("warning")) {
      return "suspicious";
    }
    return "safe";
  }

  function showWarning(result) {
    if (warningShown) return;

    const verdict = normalizeVerdict(result);
    if (verdict === "safe") return;

    warningShown = true;

    const score = getValue(result, ["risk_score", "riskScore", "score"], "N/A");
    const title = verdict === "high"
      ? "Phishing / Malicious Website Detected"
      : "Suspicious Website";

    const overlay = document.createElement("div");
    overlay.id = "phishguard-warning";
    overlay.innerHTML = `
      <div class="pg-backdrop">
        <div class="pg-card" role="dialog" aria-modal="true">
          <div class="pg-logo">🛡️</div>
          <h1>${title}</h1>
          <p class="pg-subtitle">
            PhishGuard AI detected characteristics that may indicate a security risk.
          </p>
          <div class="pg-score">Risk Score: <strong>${score}/100</strong></div>
          <p class="pg-advice">
            Do not enter passwords, OTPs, card details, or other sensitive information
            unless you are certain this website is legitimate.
          </p>
          <div class="pg-actions">
            <button id="pg-go-back">← Go Back</button>
            <button id="pg-continue">Continue Anyway</button>
          </div>
        </div>
      </div>
    `;

    const style = document.createElement("style");
    style.textContent = `
      #phishguard-warning, #phishguard-warning * { box-sizing: border-box; }
      .pg-backdrop {
        position: fixed; inset: 0; z-index: 2147483647;
        display: flex; align-items: center; justify-content: center;
        background: rgba(8, 12, 20, .88);
        font-family: Arial, sans-serif;
      }
      .pg-card {
        width: min(560px, calc(100vw - 32px));
        padding: 32px;
        border-radius: 18px;
        background: #fff;
        color: #111827;
        text-align: center;
        box-shadow: 0 25px 80px rgba(0,0,0,.45);
      }
      .pg-logo { font-size: 46px; margin-bottom: 8px; }
      .pg-card h1 { margin: 0 0 12px; font-size: 28px; }
      .pg-subtitle, .pg-advice { line-height: 1.55; color: #4b5563; }
      .pg-score {
        margin: 22px 0;
        padding: 14px;
        border-radius: 12px;
        background: #fef2f2;
        color: #b91c1c;
        font-size: 18px;
      }
      .pg-actions {
        display: flex; gap: 12px; justify-content: center; margin-top: 22px;
      }
      .pg-actions button {
        border: 0; border-radius: 10px; padding: 12px 18px;
        cursor: pointer; font-weight: 700; font-size: 14px;
      }
      #pg-go-back { background: #111827; color: white; }
      #pg-continue { background: #e5e7eb; color: #111827; }
    `;

    document.documentElement.appendChild(style);
    document.documentElement.appendChild(overlay);

    document.getElementById("pg-go-back").onclick = () => history.back();
    document.getElementById("pg-continue").onclick = () => {
      overlay.remove();
      style.remove();
    };
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "PHISHGUARD_RESULT") {
      showWarning(message.result);
    }
  });
})();