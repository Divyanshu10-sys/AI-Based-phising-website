# PhishGuard — PS-31

Integrated source for **AI-Based Phishing Website Detection System**, KAVACH
2023 problem statement PS-31.

The project combines the five submitted contributions:

- **Member 1:** URL, HTML, and DOM feature extraction with an explainable
  rule-based baseline.
- **Member 2:** presentation generator, preserved under `presentation/`.
  The submission is a PPTX generator, not a trained classifier, so the API
  uses an explainable fallback until `backend/model.joblib` or
  `backend/model.pkl` is supplied.
- **Member 3:** WHOIS domain age, SSL certificate, and optional VirusTotal
  intelligence.
- **Member 4:** FastAPI pipeline, composite scoring, SQLite history, and
  analytics.
- **Member 5:** Next.js dashboard, now connected to the live API rather than
  deterministic mock responses.

## Run the backend

```bash
cd backend
python -m venv .venv
. .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

The API is available at `http://localhost:8000` and documents itself at
`http://localhost:8000/docs`.

Optional VirusTotal enrichment is enabled by setting `VIRUSTOTAL_API_KEY` in
the environment. Do not put the key in source code.

## Run the dashboard

In another terminal:

```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`. The single URL scan, CSV batch scan, and
analytics panels use the FastAPI service.

## Generate the presentation

```bash
cd presentation
npm install
npm run generate
```

This produces `PS31_Phishing_Detection.pptx`.

## API endpoints

- `GET /api/v1/health`
- `POST /api/v1/analyze` with `{ "url": "https://example.com" }`
- `POST /api/v1/analyze/batch` with `{ "urls": ["https://example.com"] }`
- `GET /api/v1/history`
- `GET /api/v1/analytics`

## Safety notes

The feature extractor uses short timeouts and never requires VirusTotal to
operate. A missing WHOIS response, certificate, or optional threat lookup is
returned as an explicit unavailable signal instead of being treated as a
successful safe result. This is a detection aid, not a replacement for
browser security controls.

## Change log

See `CHANGES.md` for the member-by-member list of integration fixes.

The original uploaded ZIP submissions are retained in
`original_submissions/` for traceability.