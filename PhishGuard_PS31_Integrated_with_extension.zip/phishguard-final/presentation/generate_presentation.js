const pptxgen = require("pptxgenjs");

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3 x 7.5

// ---------- Palette ----------
const NAVY_DARK = "0D1B2A"; // primary dark bg
const NAVY_PANEL = "13253D"; // code editor panel bg
const NAVY_PANEL2 = "1B3B5F"; // secondary panel / cards on dark
const LIGHT_BG = "F5F7FA"; // content slide bg
const CARD_LIGHT = "FFFFFF";
const ACCENT_RED = "E63946"; // phishing / alert
const ACCENT_TEAL = "2EC4B6"; // legit / safe / success
const ACCENT_AMBER = "F4A63A"; // medium risk
const TEXT_LIGHT = "F5F7FA";
const TEXT_MUTED_ON_DARK = "8DA3C0";
const TEXT_DARK = "16263B";
const TEXT_MUTED_ON_LIGHT = "5B6B82";
const CODE_TEXT = "BFEFD0"; // terminal green-ish
const CODE_MUTED = "6E93A8"; // comments in code
const BORDER_SOFT = "DDE4EC";

const FONT_HEAD = "Cambria";
const FONT_BODY = "Calibri";
const FONT_CODE = "Courier New";

// ---------- Helpers ----------
function terminalWindow(slide, { x, y, w, h, title }) {
  slide.addShape("roundRect", {
    x, y, w, h,
    rectRadius: 0.08,
    fill: { color: NAVY_PANEL },
    line: { color: "0A1520", width: 1 },
    shadow: {
      type: "outer", color: "000000", opacity: 0.35,
      blur: 8, offset: 3, angle: 90,
    },
  });
  // title bar
  slide.addShape("roundRect", {
    x, y, w, h: 0.36,
    rectRadius: 0.08,
    fill: { color: "0F2036" },
    line: { type: "none" },
  });
  // cover bottom rounding
  slide.addShape("rect", {
    x, y: y + 0.18, w, h: 0.18,
    fill: { color: "0F2036" },
    line: { type: "none" },
  });
  const dotColors = ["FF5F56", "FFBD2E", "27C93F"];
  dotColors.forEach((c, i) => {
    slide.addShape("ellipse", {
      x: x + 0.14 + i * 0.22, y: y + 0.11, w: 0.14, h: 0.14,
      fill: { color: c }, line: { type: "none" },
    });
  });
  if (title) {
    slide.addText(title, {
      x: x + 0.9, y: y, w: w - 1.1, h: 0.36,
      fontFace: FONT_CODE, fontSize: 11, color: TEXT_MUTED_ON_DARK,
      align: "left", valign: "middle", margin: 0,
    });
  }
  return { codeX: x + 0.28, codeY: y + 0.52, codeW: w - 0.56, codeH: h - 0.74 };
}

function codeLines(slide, area, lines, fontSize) {
  const runs = [];
  lines.forEach((line, i) => {
    runs.push({
      text: line.text,
      options: {
        color: line.color || CODE_TEXT,
        breakLine: i < lines.length - 1,
      },
    });
  });
  slide.addText(runs, {
    x: area.codeX, y: area.codeY, w: area.codeW, h: area.codeH,
    fontFace: FONT_CODE, fontSize: fontSize || 13,
    align: "left", valign: "top", margin: 0, lineSpacingMultiple: 1.18,
  });
}

function pageNum(slide, n, dark) {
  slide.addText(`${n}`, {
    x: 12.7, y: 7.08, w: 0.5, h: 0.3,
    fontFace: FONT_BODY, fontSize: 10,
    color: dark ? TEXT_MUTED_ON_DARK : TEXT_MUTED_ON_LIGHT,
    align: "right",
  });
}

function kicker(slide, text, dark) {
  slide.addText(text.toUpperCase(), {
    x: 0.6, y: 0.42, w: 8, h: 0.3,
    fontFace: FONT_BODY, bold: true, fontSize: 12, charSpacing: 2,
    color: ACCENT_RED, align: "left",
  });
}

function slideTitle(slide, text, dark, opts = {}) {
  slide.addText(text, {
    x: 0.6, y: opts.y || 0.7, w: opts.w || 10.5, h: 0.7,
    fontFace: FONT_HEAD, bold: true, fontSize: 30,
    color: dark ? TEXT_LIGHT : TEXT_DARK, align: "left",
  });
}

// =====================================================================
// SLIDE 1 — Title
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };

  for (let i = 0; i < 14; i++) {
    s.addShape("ellipse", {
      x: 0.5 + i * 0.92, y: 6.55, w: 0.03, h: 0.03,
      fill: { color: NAVY_PANEL2 }, line: { type: "none" },
    });
  }

  s.addText("PS-31  ·  KAVACH 2023", {
    x: 0.9, y: 1.7, w: 8, h: 0.4,
    fontFace: FONT_BODY, bold: true, fontSize: 14, charSpacing: 3,
    color: ACCENT_RED, align: "left",
  });

  s.addText("AI-Based Phishing Website\nDetection System", {
    x: 0.85, y: 2.15, w: 11, h: 2.0,
    fontFace: FONT_HEAD, bold: true, fontSize: 44,
    color: TEXT_LIGHT, align: "left", lineSpacingMultiple: 1.05,
  });

  s.addText("Machine Learning Model & Training Pipeline", {
    x: 0.9, y: 4.15, w: 9.5, h: 0.5,
    fontFace: FONT_BODY, fontSize: 20, color: TEXT_MUTED_ON_DARK,
    align: "left",
  });

  const chips = ["Python", "scikit-learn", "XGBoost", "pandas", "numpy", "joblib"];
  let cx = 0.9;
  chips.forEach((c) => {
    const w = 0.22 + c.length * 0.11;
    s.addShape("roundRect", {
      x: cx, y: 4.95, w, h: 0.42, rectRadius: 0.06,
      fill: { color: NAVY_PANEL2 }, line: { color: "2A4A70", width: 1 },
    });
    s.addText(c, {
      x: cx, y: 4.95, w, h: 0.42, fontFace: FONT_CODE, fontSize: 12,
      color: CODE_TEXT, align: "center", valign: "middle", margin: 0,
    });
    cx += w + 0.16;
  });

  s.addShape("line", {
    x: 0.9, y: 6.15, w: 3.0, h: 0,
    line: { color: ACCENT_RED, width: 2 },
  });
  s.addText("model.pkl  +  predictor.py", {
    x: 0.9, y: 6.28, w: 6, h: 0.4,
    fontFace: FONT_CODE, fontSize: 13, color: ACCENT_TEAL, align: "left",
  });
}

// =====================================================================
// SLIDE 2 — Problem statement
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: LIGHT_BG };
  kicker(s, "The Problem Statement");
  slideTitle(s, "Real-time phishing detection,\ntrained end-to-end", false, { w: 7.2, h: 1.3 });

  const tasks = [
    ["1", "Train classifiers", "Random Forest, XGBoost, or LightGBM"],
    ["2", "Evaluate performance", "Accuracy, precision, recall, F1-score"],
    ["3", "Export trained weights", "Serialized to .pkl / .joblib"],
    ["4", "Write a prediction wrapper", "Light, dependency-minimal inference"],
  ];
  let ty = 2.15;
  tasks.forEach(([n, head, sub]) => {
    s.addShape("ellipse", {
      x: 0.6, y: ty, w: 0.5, h: 0.5,
      fill: { color: NAVY_DARK }, line: { type: "none" },
    });
    s.addText(n, {
      x: 0.6, y: ty, w: 0.5, h: 0.5, fontFace: FONT_HEAD, bold: true,
      fontSize: 18, color: TEXT_LIGHT, align: "center", valign: "middle", margin: 0,
    });
    s.addText(head, {
      x: 1.3, y: ty - 0.06, w: 5.8, h: 0.35,
      fontFace: FONT_BODY, bold: true, fontSize: 16, color: TEXT_DARK, margin: 0,
    });
    s.addText(sub, {
      x: 1.3, y: ty + 0.28, w: 5.8, h: 0.32,
      fontFace: FONT_BODY, fontSize: 12.5, color: TEXT_MUTED_ON_LIGHT, margin: 0,
    });
    ty += 0.98;
  });

  s.addShape("roundRect", {
    x: 8.1, y: 2.1, w: 4.6, h: 4.0, rectRadius: 0.12,
    fill: { color: NAVY_DARK }, line: { type: "none" },
    shadow: { type: "outer", color: "000000", opacity: 0.25, blur: 10, offset: 4, angle: 90 },
  });
  s.addText("DELIVERABLES", {
    x: 8.4, y: 2.35, w: 4, h: 0.3, fontFace: FONT_BODY, bold: true,
    fontSize: 12, charSpacing: 2, color: ACCENT_RED, margin: 0,
  });
  const files = [
    ["model.pkl", "Serialized best-performing classifier + metadata"],
    ["predictor.py", "PhishingPredictor — the integration surface"],
    ["feature_extractor.py", "Shared URL -> feature-vector contract"],
    ["train_model.py", "Reproducible training & evaluation pipeline"],
  ];
  let fy = 2.85;
  files.forEach(([name, desc]) => {
    s.addShape("roundRect", {
      x: 8.4, y: fy, w: 3.9, h: 0.72, rectRadius: 0.06,
      fill: { color: NAVY_PANEL2 }, line: { type: "none" },
    });
    s.addText(name, {
      x: 8.55, y: fy + 0.06, w: 3.6, h: 0.3, fontFace: FONT_CODE, bold: true,
      fontSize: 13, color: CODE_TEXT, margin: 0,
    });
    s.addText(desc, {
      x: 8.55, y: fy + 0.36, w: 3.6, h: 0.3, fontFace: FONT_BODY,
      fontSize: 10.5, color: TEXT_MUTED_ON_DARK, margin: 0,
    });
    fy += 0.83;
  });

  pageNum(s, 2, false);
}

// =====================================================================
// SLIDE 3 — Pipeline architecture
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: LIGHT_BG };
  kicker(s, "Architecture");
  slideTitle(s, "How the five files fit together", false);

  const stages = [
    ["feature_extractor.py", "URL -> 22 numeric features", ACCENT_TEAL],
    ["generate_dataset.py", "url,label training data", ACCENT_AMBER],
    ["train_model.py", "Train + evaluate + select", ACCENT_AMBER],
    ["model.pkl", "Serialized best model", NAVY_DARK],
    ["predictor.py", "predict(url) -> dict", ACCENT_RED],
  ];
  const startX = 0.6, boxW = 2.15, gap = 0.28, boxY = 2.6, boxH = 1.5;
  stages.forEach((stg, i) => {
    const x = startX + i * (boxW + gap);
    s.addShape("roundRect", {
      x, y: boxY, w: boxW, h: boxH, rectRadius: 0.1,
      fill: { color: CARD_LIGHT }, line: { color: BORDER_SOFT, width: 1 },
      shadow: { type: "outer", color: "16263B", opacity: 0.12, blur: 6, offset: 2, angle: 90 },
    });
    s.addShape("roundRect", {
      x: x + 0.18, y: boxY + 0.18, w: 0.4, h: 0.4, rectRadius: 0.08,
      fill: { color: stg[2] }, line: { type: "none" },
    });
    s.addText(stg[0], {
      x: x + 0.16, y: boxY + 0.66, w: boxW - 0.32, h: 0.5,
      fontFace: FONT_CODE, bold: true, fontSize: 11.5, color: TEXT_DARK,
      margin: 0, valign: "top",
    });
    s.addText(stg[1], {
      x: x + 0.16, y: boxY + 1.08, w: boxW - 0.32, h: 0.38,
      fontFace: FONT_BODY, fontSize: 9.5, color: TEXT_MUTED_ON_LIGHT,
      margin: 0, valign: "top",
    });
    if (i < stages.length - 1) {
      s.addText("\u2192", {
        x: x + boxW, y: boxY, w: gap, h: boxH,
        fontFace: FONT_BODY, bold: true, fontSize: 20, color: TEXT_MUTED_ON_LIGHT,
        align: "center", valign: "middle", margin: 0,
      });
    }
  });

  s.addShape("roundRect", {
    x: 0.6, y: 4.65, w: 12.1, h: 1.3, rectRadius: 0.1,
    fill: { color: NAVY_DARK }, line: { type: "none" },
  });
  s.addText("Team hand-off point", {
    x: 0.9, y: 4.85, w: 4, h: 0.3, fontFace: FONT_BODY, bold: true,
    fontSize: 12, color: ACCENT_TEAL, margin: 0,
  });
  s.addText("predictor.py is the only file the API / browser-extension team needs to import. It has no web-framework dependency: from predictor import PhishingPredictor \u2192 predictor.predict(url).", {
    x: 0.9, y: 5.15, w: 11.5, h: 0.7,
    fontFace: FONT_BODY, fontSize: 13, color: TEXT_LIGHT, margin: 0, lineSpacingMultiple: 1.15,
  });

  pageNum(s, 3, false);
}

// =====================================================================
// SLIDE 4 — feature_extractor.py
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };
  kicker(s, "File 1 of 4");
  slideTitle(s, "feature_extractor.py", true);
  s.addText("Turns a raw URL into a fixed-length numeric vector \u2014 stdlib only, no network calls, so it's fast enough for real-time inference.", {
    x: 0.6, y: 1.35, w: 8.5, h: 0.5,
    fontFace: FONT_BODY, fontSize: 13.5, color: TEXT_MUTED_ON_DARK, margin: 0,
  });

  const area = terminalWindow(s, { x: 0.6, y: 2.05, w: 8.0, h: 4.85, title: "feature_extractor.py" });
  codeLines(s, area, [
    { text: "def extract_features(url: str) -> dict:", color: "FFD479" },
    { text: "    hostname = urlparse(url).hostname or \"\"" },
    { text: "    digits = sum(c.isdigit() for c in url)" },
    { text: "" },
    { text: "    return {" },
    { text: "        \"url_length\": len(url)," },
    { text: "        \"has_ip\": 1 if IP_PATTERN.match(hostname) else 0," },
    { text: "        \"has_https\": 1 if parsed.scheme == \"https\" else 0," },
    { text: "        \"suspicious_word_count\": sum(", color: CODE_TEXT },
    { text: "            1 for w in SUSPICIOUS_WORDS if w in url.lower()" },
    { text: "        )," },
    { text: "        \"is_shortened\": 1 if hostname in SHORTENERS else 0," },
    { text: "        \"suspicious_tld\": 1 if tld in SUSPICIOUS_TLDS else 0," },
    { text: "        # ... 22 features total", color: CODE_MUTED },
    { text: "    }" },
  ], 13.5);

  const fams = [
    ["Structural", "url_length, hostname_length, path_length"],
    ["Character counts", "dots, hyphens, @, =, %, digit_ratio ..."],
    ["Security signals", "has_ip, is_shortened, suspicious_tld"],
    ["Content cues", "suspicious_word_count (login, verify, ...)"],
  ];
  let fy = 2.1;
  fams.forEach(([h, d]) => {
    s.addShape("roundRect", {
      x: 8.95, y: fy, w: 3.75, h: 1.02, rectRadius: 0.08,
      fill: { color: NAVY_PANEL2 }, line: { type: "none" },
    });
    s.addText(h, {
      x: 9.15, y: fy + 0.12, w: 3.4, h: 0.3, fontFace: FONT_BODY, bold: true,
      fontSize: 13, color: ACCENT_TEAL, margin: 0,
    });
    s.addText(d, {
      x: 9.15, y: fy + 0.44, w: 3.4, h: 0.5, fontFace: FONT_BODY,
      fontSize: 10.5, color: TEXT_MUTED_ON_DARK, margin: 0, lineSpacingMultiple: 1.1,
    });
    fy += 1.17;
  });

  pageNum(s, 4, true);
}

// =====================================================================
// SLIDE 5 — generate_dataset.py
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };
  kicker(s, "File 2 of 4");
  slideTitle(s, "generate_dataset.py", true);
  s.addText("Produces data/urls_dataset.csv (url,label) so the pipeline is runnable end-to-end today.", {
    x: 0.6, y: 1.35, w: 8.3, h: 0.5,
    fontFace: FONT_BODY, fontSize: 13.5, color: TEXT_MUTED_ON_DARK, margin: 0,
  });

  const area = terminalWindow(s, { x: 0.6, y: 2.05, w: 8.0, h: 4.1, title: "generate_dataset.py" });
  codeLines(s, area, [
    { text: "def random_phish_url():", color: "FFD479" },
    { text: "    brand = random.choice(PHISH_BRANDS)   # \"sbi\", \"paypal\" ..." },
    { text: "    word  = random.choice(PHISH_WORDS)    # \"verify\", \"login\" ..." },
    { text: "    tld   = random.choice(PHISH_TLDS)     # \".tk\", \".xyz\" ..." },
    { text: "    host  = f\"{brand}-{word}.{tld}\"" },
    { text: "    return f\"http://{host}/confirm?token={rand()}\"" },
    { text: "" },
    { text: "# generate(1200) -> 1200 legit + 1200 phishing rows", color: CODE_MUTED },
  ], 14);

  s.addShape("roundRect", {
    x: 0.6, y: 6.3, w: 8.0, h: 0.85, rectRadius: 0.1,
    fill: { color: "3A1620" }, line: { color: ACCENT_RED, width: 1 },
  });
  s.addShape("ellipse", {
    x: 0.82, y: 6.5, w: 0.42, h: 0.42, fill: { color: ACCENT_RED }, line: { type: "none" },
  });
  s.addText("!", {
    x: 0.82, y: 6.5, w: 0.42, h: 0.42, fontFace: FONT_HEAD, bold: true,
    fontSize: 18, color: TEXT_LIGHT, align: "center", valign: "middle", margin: 0,
  });
  s.addText("This is a rule-based placeholder \u2014 the sandbox has no internet to pull the real UCI / PhishTank data. Swap in a real url,label CSV; train_model.py needs no changes.", {
    x: 1.4, y: 6.4, w: 7.0, h: 0.65,
    fontFace: FONT_BODY, fontSize: 11.5, color: TEXT_LIGHT, margin: 0, lineSpacingMultiple: 1.12,
  });

  const steps = [
    "Download PhishTank online-valid.csv + a legit URL list (Tranco top sites)",
    "Save as data/urls_dataset.csv with columns url,label",
    "Re-run train_model.py \u2014 same schema, zero code changes",
  ];
  s.addText("SWAP-IN PLAN FOR REAL DATA", {
    x: 8.95, y: 2.1, w: 3.8, h: 0.3, fontFace: FONT_BODY, bold: true,
    fontSize: 12, charSpacing: 1, color: ACCENT_TEAL, margin: 0,
  });
  let sy = 2.55;
  steps.forEach((st, i) => {
    s.addShape("ellipse", {
      x: 8.95, y: sy, w: 0.34, h: 0.34, fill: { color: NAVY_PANEL2 }, line: { type: "none" },
    });
    s.addText(`${i + 1}`, {
      x: 8.95, y: sy, w: 0.34, h: 0.34, fontFace: FONT_BODY, bold: true, fontSize: 12,
      color: TEXT_LIGHT, align: "center", valign: "middle", margin: 0,
    });
    s.addText(st, {
      x: 9.42, y: sy - 0.05, w: 3.3, h: 0.75, fontFace: FONT_BODY, fontSize: 11,
      color: TEXT_MUTED_ON_DARK, margin: 0, lineSpacingMultiple: 1.15,
    });
    sy += 0.95;
  });

  pageNum(s, 5, true);
}

// =====================================================================
// SLIDE 6 — train_model.py
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };
  kicker(s, "File 3 of 4");
  slideTitle(s, "train_model.py", true);
  s.addText("Trains every available classifier, evaluates on a held-out split, and keeps the best by F1-score.", {
    x: 0.6, y: 1.35, w: 8.3, h: 0.5,
    fontFace: FONT_BODY, fontSize: 13.5, color: TEXT_MUTED_ON_DARK, margin: 0,
  });

  const area = terminalWindow(s, { x: 0.6, y: 2.05, w: 8.0, h: 4.85, title: "train_model.py" });
  codeLines(s, area, [
    { text: "def get_candidate_models() -> dict:", color: "FFD479" },
    { text: "    models = {" },
    { text: "        \"RandomForest\": RandomForestClassifier(300)," },
    { text: "        \"GradientBoosting\": GradientBoostingClassifier()," },
    { text: "    }" },
    { text: "    try:", color: CODE_MUTED },
    { text: "        from xgboost import XGBClassifier   # if installed", color: CODE_MUTED },
    { text: "        models[\"XGBoost\"] = XGBClassifier(300)", color: CODE_MUTED },
    { text: "    except ImportError: pass", color: CODE_MUTED },
    { text: "    return models" },
    { text: "" },
    { text: "for name, model in get_candidate_models().items():", color: "FFD479" },
    { text: "    model.fit(X_train, y_train)" },
    { text: "    score_and_compare(model, X_test, y_test)" },
    { text: "best = max(results, key=lambda n: results[n][\"f1_score\"])" },
  ], 13);

  const bullets = [
    "Auto-detects XGBoost / LightGBM \u2014 uses them if installed, falls back to sklearn otherwise",
    "80/20 stratified train-test split",
    "Saves accuracy, precision, recall, F1 for every model to metrics.json",
    "Serializes the winner + feature schema to model.pkl via joblib",
  ];
  let by = 2.15;
  s.addText("PIPELINE BEHAVIOR", {
    x: 8.95, y: by, w: 3.8, h: 0.3, fontFace: FONT_BODY, bold: true,
    fontSize: 12, charSpacing: 1, color: ACCENT_TEAL, margin: 0,
  });
  by += 0.42;
  bullets.forEach((b) => {
    s.addShape("roundRect", {
      x: 8.95, y: by, w: 0.08, h: 0.7, fill: { color: "2A4A70" }, line: { type: "none" },
    });
    s.addText(b, {
      x: 9.15, y: by - 0.03, w: 3.55, h: 0.8, fontFace: FONT_BODY, fontSize: 11,
      color: TEXT_LIGHT, margin: 0, lineSpacingMultiple: 1.15, valign: "top",
    });
    by += 0.93;
  });

  pageNum(s, 6, true);
}

// =====================================================================
// SLIDE 7 — Evaluation results
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: LIGHT_BG };
  kicker(s, "Evaluation");
  slideTitle(s, "Accuracy, precision, recall, F1", false);

  const metrics = [
    ["Accuracy", "100%"],
    ["Precision", "100%"],
    ["Recall", "100%"],
    ["F1-score", "100%"],
  ];
  let mx = 0.6;
  metrics.forEach(([label, val]) => {
    s.addShape("roundRect", {
      x: mx, y: 2.15, w: 2.85, h: 1.9, rectRadius: 0.12,
      fill: { color: CARD_LIGHT }, line: { color: BORDER_SOFT, width: 1 },
      shadow: { type: "outer", color: "16263B", opacity: 0.1, blur: 6, offset: 2, angle: 90 },
    });
    s.addText(val, {
      x: mx, y: 2.35, w: 2.85, h: 1.0, fontFace: FONT_HEAD, bold: true,
      fontSize: 46, color: ACCENT_TEAL, align: "center", margin: 0,
    });
    s.addText(label.toUpperCase(), {
      x: mx, y: 3.45, w: 2.85, h: 0.4, fontFace: FONT_BODY, bold: true,
      fontSize: 12, charSpacing: 1.5, color: TEXT_MUTED_ON_LIGHT, align: "center", margin: 0,
    });
    mx += 3.05;
  });

  s.addText("Best model selected: RandomForestClassifier  (GradientBoosting tied on every metric)", {
    x: 0.6, y: 4.35, w: 12, h: 0.4, fontFace: FONT_BODY, italic: true, fontSize: 13,
    color: TEXT_MUTED_ON_LIGHT, margin: 0,
  });

  s.addShape("roundRect", {
    x: 0.6, y: 4.95, w: 12.1, h: 1.55, rectRadius: 0.1,
    fill: { color: NAVY_DARK }, line: { type: "none" },
  });
  s.addShape("ellipse", {
    x: 0.92, y: 5.2, w: 0.42, h: 0.42, fill: { color: ACCENT_RED }, line: { type: "none" },
  });
  s.addText("!", {
    x: 0.92, y: 5.2, w: 0.42, h: 0.42, fontFace: FONT_HEAD, bold: true,
    fontSize: 18, color: TEXT_LIGHT, align: "center", valign: "middle", margin: 0,
  });
  s.addText("Read this before trusting the numbers", {
    x: 1.5, y: 5.15, w: 10.8, h: 0.35, fontFace: FONT_BODY, bold: true,
    fontSize: 14, color: ACCENT_RED, margin: 0,
  });
  s.addText("100% F1 is expected, not impressive \u2014 the model was trained on the rule-based synthetic dataset from generate_dataset.py, so it simply learned the generator's own rules. This proves the pipeline runs end-to-end; it is not a validated real-world detector until the real PhishTank/UCI data is swapped in.", {
    x: 1.5, y: 5.5, w: 10.8, h: 0.9, fontFace: FONT_BODY, fontSize: 12,
    color: TEXT_LIGHT, margin: 0, lineSpacingMultiple: 1.2,
  });

  pageNum(s, 7, false);
}

// =====================================================================
// SLIDE 8 — predictor.py
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };
  kicker(s, "File 4 of 4 \u2014 The Deliverable");
  slideTitle(s, "predictor.py", true);
  s.addText("Loads model.pkl once, exposes .predict(url) \u2014 the one function the rest of the team needs.", {
    x: 0.6, y: 1.35, w: 8.5, h: 0.5,
    fontFace: FONT_BODY, fontSize: 13.5, color: TEXT_MUTED_ON_DARK, margin: 0,
  });

  const area = terminalWindow(s, { x: 0.6, y: 2.05, w: 8.0, h: 4.85, title: "predictor.py" });
  codeLines(s, area, [
    { text: "class PhishingPredictor:", color: "FFD479" },
    { text: "    def __init__(self, model_path=DEFAULT_MODEL_PATH):" },
    { text: "        bundle = joblib.load(model_path)" },
    { text: "        self.model = bundle[\"model\"]" },
    { text: "        self.feature_names = bundle[\"feature_names\"]" },
    { text: "" },
    { text: "    def predict(self, url: str) -> dict:", color: "FFD479" },
    { text: "        vector = extract_feature_vector(url)" },
    { text: "        proba = self.model.predict_proba([vector])[0]" },
    { text: "        phishing_prob = proba[self.model.classes_.index(1)]" },
    { text: "        return {" },
    { text: "            \"is_phishing\": phishing_prob >= 0.5," },
    { text: "            \"phishing_probability\": round(phishing_prob, 4)," },
    { text: "            \"risk_level\": self._risk_level(phishing_prob)," },
    { text: "        }" },
  ], 13);

  const bullets = [
    "No web-framework dependency \u2014 drop into Flask, FastAPI, or a browser-extension backend",
    "predict_batch(urls) for scoring many URLs at once",
    "risk_level: low / medium / high, ready for a UI badge",
  ];
  let by = 2.15;
  s.addText("WHY IT'S EASY TO MERGE", {
    x: 8.95, y: by, w: 3.8, h: 0.3, fontFace: FONT_BODY, bold: true,
    fontSize: 12, charSpacing: 1, color: ACCENT_TEAL, margin: 0,
  });
  by += 0.42;
  bullets.forEach((b) => {
    s.addShape("roundRect", {
      x: 8.95, y: by, w: 0.08, h: 0.85, fill: { color: "2A4A70" }, line: { type: "none" },
    });
    s.addText(b, {
      x: 9.15, y: by - 0.03, w: 3.55, h: 0.95, fontFace: FONT_BODY, fontSize: 11.5,
      color: TEXT_LIGHT, margin: 0, lineSpacingMultiple: 1.18, valign: "top",
    });
    by += 1.1;
  });

  pageNum(s, 8, true);
}

// =====================================================================
// SLIDE 9 — Sample predictions
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: LIGHT_BG };
  kicker(s, "In Action");
  slideTitle(s, "Three URLs through the model", false);

  const rows = [
    ["https://www.google.com", "0.0%", "LOW", ACCENT_TEAL],
    ["http://paypal-secure-login.verify-account.tk/confirm?user=1", "95.7%", "HIGH", ACCENT_RED],
    ["http://192.168.10.5/sbi/login.php", "83.7%", "HIGH", ACCENT_RED],
  ];
  let ry = 2.25;
  rows.forEach(([url, prob, risk, color]) => {
    s.addShape("roundRect", {
      x: 0.6, y: ry, w: 12.1, h: 1.05, rectRadius: 0.1,
      fill: { color: CARD_LIGHT }, line: { color: BORDER_SOFT, width: 1 },
      shadow: { type: "outer", color: "16263B", opacity: 0.08, blur: 5, offset: 2, angle: 90 },
    });
    s.addText(url, {
      x: 0.9, y: ry, w: 8.3, h: 1.05, fontFace: FONT_CODE, fontSize: 13,
      color: TEXT_DARK, valign: "middle", margin: 0,
    });
    s.addText(prob, {
      x: 9.3, y: ry, w: 1.5, h: 1.05, fontFace: FONT_HEAD, bold: true, fontSize: 20,
      color: TEXT_DARK, align: "center", valign: "middle", margin: 0,
    });
    s.addShape("roundRect", {
      x: 11.0, y: ry + 0.28, w: 1.35, h: 0.5, rectRadius: 0.25,
      fill: { color }, line: { type: "none" },
    });
    s.addText(risk, {
      x: 11.0, y: ry + 0.28, w: 1.35, h: 0.5, fontFace: FONT_BODY, bold: true,
      fontSize: 12, color: TEXT_LIGHT, align: "center", valign: "middle", margin: 0,
    });
    ry += 1.25;
  });

  s.addText("predictor.predict(url)  \u2192  { url, is_phishing, phishing_probability, risk_level, model_name, features }", {
    x: 0.6, y: 6.05, w: 12.1, h: 0.4, fontFace: FONT_CODE, fontSize: 12,
    color: TEXT_MUTED_ON_LIGHT, align: "left", margin: 0,
  });

  pageNum(s, 9, false);
}

// =====================================================================
// SLIDE 10 — Integration contract (FIXED BUG HERE)
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: LIGHT_BG };
  kicker(s, "For The Team");
  slideTitle(s, "One import, one function call", false, { w: 7 });

  // Fixed text box dimensions & breakLine formatting
  s.addText([
    { text: "from predictor import PhishingPredictor\n", options: { color: "FFD479" } },
    { text: "predictor = PhishingPredictor()   ", options: { color: TEXT_DARK } },
    { text: "# loads model.pkl once\n", options: { color: TEXT_MUTED_ON_LIGHT } },
    { text: "result = predictor.predict(url)", options: { color: TEXT_DARK } },
  ], {
    x: 0.6, y: 1.55, w: 12.1, h: 0.85, fontFace: FONT_CODE, fontSize: 13,
    margin: 0,
  });

  const area = terminalWindow(s, { x: 0.6, y: 2.5, w: 6.0, h: 4.4, title: "result.json" });
  codeLines(s, area, [
    { text: "{" },
    { text: "  \"url\": \"http://paypal-secure...\"," },
    { text: "  \"is_phishing\": true,", color: ACCENT_RED },
    { text: "  \"phishing_probability\": 0.9567," },
    { text: "  \"risk_level\": \"high\",", color: ACCENT_RED },
    { text: "  \"model_name\": \"RandomForest\"," },
    { text: "  \"features\": {" },
    { text: "    \"url_length\": 59," },
    { text: "    \"has_ip\": 0," },
    { text: "    \"...\": \"...\"" },
    { text: "  }" },
    { text: "}" },
  ], 13);

  const explain = [
    ["is_phishing", "Boolean, thresholded at 0.5 probability"],
    ["phishing_probability", "Float 0\u20131, use for a custom threshold"],
    ["risk_level", "low / medium / high, for a UI badge"],
    ["features", "Included for logging & explainability"],
  ];
  let ey = 2.6;
  explain.forEach(([h, d]) => {
    s.addText(h, {
      x: 6.95, y: ey, w: 5.6, h: 0.3, fontFace: FONT_CODE, bold: true,
      fontSize: 13, color: TEXT_DARK, margin: 0,
    });
    s.addText(d, {
      x: 6.95, y: ey + 0.32, w: 5.6, h: 0.35, fontFace: FONT_BODY,
      fontSize: 11.5, color: TEXT_MUTED_ON_LIGHT, margin: 0,
    });
    ey += 0.98;
  });

  pageNum(s, 10, false);
}

// =====================================================================
// SLIDE 11 — What's next
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: LIGHT_BG };
  kicker(s, "Roadmap");
  slideTitle(s, "What I'd extend first", false);

  const items = [
    ["Swap in the real dataset", "PhishTank + Tranco/UCI, same url,label schema \u2014 top priority before trusting the numbers"],
    ["Network-based features", "Domain age, SSL issuer, DNS records \u2014 strong signals, but need caching/timeouts in the API layer"],
    ["Cross-validation & tuning", "GridSearchCV / RandomizedSearchCV once the dataset is real and noisier"],
    ["Model versioning", "Timestamp/hash in the model.pkl bundle so the API can log which version predicted"],
    ["Threshold calibration", "Tune the 0.5 cutoff against the team's acceptable false-positive rate"],
  ];
  let iy = 2.1;
  items.forEach(([h, d], i) => {
    const col = i % 2;
    const x = 0.6 + col * 6.3;
    if (col === 0 && i > 0) iy += 1.55;
    s.addShape("roundRect", {
      x, y: iy, w: 5.9, h: 1.35, rectRadius: 0.1,
      fill: { color: CARD_LIGHT }, line: { color: BORDER_SOFT, width: 1 },
      shadow: { type: "outer", color: "16263B", opacity: 0.08, blur: 5, offset: 2, angle: 90 },
    });
    s.addShape("ellipse", {
      x: x + 0.2, y: iy + 0.18, w: 0.4, h: 0.4, fill: { color: NAVY_DARK }, line: { type: "none" },
    });
    s.addText(`${i + 1}`, {
      x: x + 0.2, y: iy + 0.18, w: 0.4, h: 0.4, fontFace: FONT_HEAD, bold: true,
      fontSize: 14, color: TEXT_LIGHT, align: "center", valign: "middle", margin: 0,
    });
    s.addText(h, {
      x: x + 0.75, y: iy + 0.14, w: 5.0, h: 0.35, fontFace: FONT_BODY, bold: true,
      fontSize: 13.5, color: TEXT_DARK, margin: 0,
    });
    s.addText(d, {
      x: x + 0.75, y: iy + 0.48, w: 5.0, h: 0.8, fontFace: FONT_BODY,
      fontSize: 10.5, color: TEXT_MUTED_ON_LIGHT, margin: 0, lineSpacingMultiple: 1.15,
    });
  });

  pageNum(s, 11, false);
}

// =====================================================================
// SLIDE 12 — Closing
// =====================================================================
{
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };

  s.addText("Ready to integrate", {
    x: 0.9, y: 2.5, w: 10, h: 0.9,
    fontFace: FONT_HEAD, bold: true, fontSize: 40, color: TEXT_LIGHT, align: "left",
  });
  s.addText("feature_extractor.py \u00b7 generate_dataset.py \u00b7 train_model.py \u00b7 predictor.py \u00b7 model.pkl", {
    x: 0.9, y: 3.4, w: 11, h: 0.5,
    fontFace: FONT_CODE, fontSize: 15, color: ACCENT_TEAL, align: "left",
  });
  s.addText("PS-31 \u00b7 AI-Based Phishing Website Detection System \u00b7 KAVACH 2023", {
    x: 0.9, y: 4.9, w: 10, h: 0.4,
    fontFace: FONT_BODY, fontSize: 13, color: TEXT_MUTED_ON_DARK, align: "left",
  });
}

// Fixed output path to work cross-platform
pres.writeFile({ fileName: "PS31_Phishing_Detection.pptx" }).then(() => {
  console.log("Successfully generated presentation!");
});