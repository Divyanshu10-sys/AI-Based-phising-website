"""
database.py
-----------
Lightweight SQLite persistence layer for the Phishing Detector backend.

Responsible for:
- Creating the scan_history table on startup
- Inserting a new scan record
- Reading paginated history (for the dashboard / extension)
- Producing aggregate analytics (for the dashboard charts)

Uses the stdlib sqlite3 module only, so there is nothing extra to install.
"""

import sqlite3
import json
import os
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Optional

DB_PATH = os.getenv(
    "PHISHGUARD_DB_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "phishing_scans.db"),
)


def init_db() -> None:
    """Create the scan_history table if it doesn't already exist."""
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scan_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                domain TEXT,
                verdict TEXT NOT NULL,
                risk_score REAL NOT NULL,
                ml_probability REAL,
                domain_age_days INTEGER,
                ssl_valid INTEGER,
                blacklisted INTEGER,
                features_json TEXT,
                intel_json TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_scan_history_created_at ON scan_history (created_at)"
        )
        conn.commit()


@contextmanager
def get_connection():
    """Context-managed SQLite connection with row access by column name."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def insert_scan(
    url: str,
    domain: Optional[str],
    verdict: str,
    risk_score: float,
    ml_probability: Optional[float],
    domain_age_days: Optional[int],
    ssl_valid: Optional[bool],
    blacklisted: Optional[bool],
    features: dict,
    intel: dict,
) -> int:
    """Insert one scan record and return its new row id."""
    with get_connection() as conn:
        cur = conn.execute(
            """
            INSERT INTO scan_history (
                url, domain, verdict, risk_score, ml_probability,
                domain_age_days, ssl_valid, blacklisted,
                features_json, intel_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                url,
                domain,
                verdict,
                risk_score,
                ml_probability,
                domain_age_days,
                int(bool(ssl_valid)) if ssl_valid is not None else None,
                int(bool(blacklisted)) if blacklisted is not None else None,
                json.dumps(features, default=str),
                json.dumps(intel, default=str),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
        return cur.lastrowid


def get_history(limit: int = 50, offset: int = 0):
    """Return the most recent scans, newest first."""
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT id, url, domain, verdict, risk_score, ml_probability,
                   domain_age_days, ssl_valid, blacklisted, created_at
            FROM scan_history
            ORDER BY id DESC
            LIMIT ? OFFSET ?
            """,
            (limit, offset),
        ).fetchall()
        return [dict(r) for r in rows]


def get_analytics():
    """Aggregate stats used by the dashboard's analytics charts."""
    with get_connection() as conn:
        total = conn.execute("SELECT COUNT(*) AS c FROM scan_history").fetchone()["c"]

        by_verdict = conn.execute(
            "SELECT verdict, COUNT(*) AS c FROM scan_history GROUP BY verdict"
        ).fetchall()

        avg_risk = conn.execute(
            "SELECT AVG(risk_score) AS avg_risk FROM scan_history"
        ).fetchone()["avg_risk"]

        recent_domains = conn.execute(
            """
            SELECT domain, COUNT(*) AS c
            FROM scan_history
            WHERE domain IS NOT NULL
            GROUP BY domain
            ORDER BY c DESC
            LIMIT 10
            """
        ).fetchall()

        age_buckets = conn.execute(
            """
            SELECT
                CASE
                    WHEN domain_age_days IS NULL THEN 'unknown'
                    WHEN domain_age_days < 30 THEN '<30 days'
                    WHEN domain_age_days < 180 THEN '30-180 days'
                    WHEN domain_age_days < 365 THEN '180-365 days'
                    ELSE '1+ years'
                END AS bucket,
                COUNT(*) AS c
            FROM scan_history
            GROUP BY bucket
            """
        ).fetchall()

        recent_rows = conn.execute(
            """
            SELECT created_at, verdict, features_json
            FROM scan_history
            ORDER BY id DESC
            LIMIT 500
            """
        ).fetchall()
        daily = defaultdict(lambda: {"scans": 0, "phishing": 0})
        keywords = Counter()
        for row in recent_rows:
            day = row["created_at"][:10]
            daily[day]["scans"] += 1
            daily[day]["phishing"] += int(row["verdict"] == "phishing")
            try:
                payload = json.loads(row["features_json"] or "{}")
                keywords.update(payload.get("suspicious_words", []))
            except (TypeError, ValueError):
                continue

        return {
            "total_scans": total,
            "by_verdict": {row["verdict"]: row["c"] for row in by_verdict},
            "average_risk_score": round(avg_risk, 2) if avg_risk is not None else 0,
            "top_domains": [dict(r) for r in recent_domains],
            "domain_age_distribution": [
                {"label": row["bucket"], "value": row["c"]} for row in age_buckets
            ],
            "daily_scans": [
                {"date": date, **values}
                for date, values in sorted(daily.items())[-7:]
            ],
            "top_keywords": [
                {"keyword": keyword, "count": count}
                for keyword, count in keywords.most_common(7)
            ],
        }
