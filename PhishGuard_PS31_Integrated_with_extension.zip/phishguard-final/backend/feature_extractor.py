import os
import re
import ipaddress
from urllib.parse import urlparse, urljoin

import requests
import tldextract
from bs4 import BeautifulSoup

TLD_EXTRACTOR = tldextract.TLDExtract(suffix_list_urls=())

SUSPICIOUS_WORDS = {
    "login",
    "signin",
    "sign-in",
    "verify",
    "verification",
    "secure",
    "security",
    "update",
    "account",
    "billing",
    "payment",
    "confirm",
    "password",
    "authenticate",
    "wallet",
    "bank",
    "free",
    "bonus",
    "urgent",
}


URL_SHORTENING_SERVICES = {
    "bit.ly",
    "tinyurl.com",
    "goo.gl",
    "ow.ly",
    "t.co",
    "is.gd",
    "buff.ly",
    "cutt.ly",
    "shorturl.at",
    "rebrand.ly",
}


def normalise_url(url):
    """
    Adds https:// when a URL does not contain a protocol.
    """
    if not isinstance(url, str) or not url.strip():
        raise ValueError("URL must not be empty")

    url = url.strip()

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    return url


def is_ip_address(hostname):
    """
    Returns 1 if the hostname is an IPv4 or IPv6 address.
    """
    if not hostname:
        return 0

    try:
        ipaddress.ip_address(hostname)
        return 1
    except ValueError:
        return 0


def get_domain(url):
    """
    Returns the registered domain.
    Example: sub.example.com becomes example.com.
    """
    extracted = TLD_EXTRACTOR(url)

    if extracted.domain and extracted.suffix:
        return extracted.domain + "." + extracted.suffix

    return extracted.domain


def get_suspicious_words(text):
    """
    Finds suspicious words in the URL or HTML.
    """
    text = text.lower()

    found_words = []

    for word in SUSPICIOUS_WORDS:
        if word in text:
            found_words.append(word)

    return sorted(set(found_words))


def is_shortened_url(hostname):
    """
    Checks whether the hostname belongs to a known URL shortener.
    """
    if not hostname:
        return 0

    hostname = hostname.lower().split(":")[0]

    return int(hostname in URL_SHORTENING_SERVICES)


def extract_url_features(url):
    """
    Extracts numerical and categorical features from a URL.
    """
    parsed_url = urlparse(url)
    hostname = parsed_url.hostname or ""

    extracted = TLD_EXTRACTOR(url)
    subdomain = extracted.subdomain

    suspicious_words = get_suspicious_words(url)

    try:
        port = parsed_url.port
    except ValueError:
        port = None

    features = {
        "url_length": len(url),
        "hostname_length": len(hostname),
        "path_length": len(parsed_url.path),
        "query_length": len(parsed_url.query),

        "num_dots": url.count("."),
        "num_hyphens": url.count("-"),
        "num_slashes": url.count("/"),
        "num_digits": sum(character.isdigit() for character in url),
        "num_special_characters": len(
            re.findall(r"[^a-zA-Z0-9]", url)
        ),

        "has_at_symbol": int("@" in url),
        "has_ip_address": is_ip_address(hostname),
        "has_https": int(parsed_url.scheme == "https"),
        "has_port": int(port is not None),
        "has_query": int(bool(parsed_url.query)),
        "has_fragment": int(bool(parsed_url.fragment)),

        "is_shortened_url": is_shortened_url(hostname),

        "subdomain_count": (
            0 if not subdomain else len(subdomain.split("."))
        ),

        "domain": get_domain(url),
        "hostname": hostname,

        "suspicious_word_count": len(suspicious_words),
        "suspicious_words": suspicious_words,
    }

    return features


def load_html_from_file(file_path):
    """
    Loads HTML from a local file.
    """
    if not os.path.exists(file_path):
        return ""

    try:
        with open(
            file_path,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as file:
            return file.read()

    except OSError:
        return ""


def fetch_html(url, timeout=10):
    """
    Downloads HTML from a live URL.

    Requests does not execute JavaScript.
    """
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    try:
        response = requests.get(
            url,
            headers=headers,
            timeout=timeout,
            allow_redirects=True
        )

        content_type = response.headers.get(
            "Content-Type",
            ""
        ).lower()

        if response.status_code == 200 and "html" in content_type:
            return response.text

    except requests.RequestException:
        pass

    return ""


def has_iframe(soup):
    """
    Detects iframe elements.
    """
    return int(soup.find("iframe") is not None)


def has_password_field(soup):
    """
    Detects password input fields.
    """
    password_fields = soup.find_all(
        "input",
        attrs={
            "type": re.compile(
                "^password$",
                re.IGNORECASE
            )
        }
    )

    return int(bool(password_fields))


def is_right_click_disabled(html):
    """
    Detects common patterns used to disable right-click.
    """
    html_lower = html.lower()

    patterns = [
        "oncontextmenu",
        "contextmenu",
        "event.button == 2",
        "event.button==2",
        "which == 3",
        "which==3",
        "return false",
    ]

    for pattern in patterns:
        if pattern in html_lower:
            return 1

    return 0


def is_external_action(action_url, page_url):
    """
    Checks whether a form submits data to another domain.
    """
    if not action_url:
        return 0

    full_action_url = urljoin(page_url, action_url)

    action_host = urlparse(full_action_url).hostname
    page_host = urlparse(page_url).hostname

    if not action_host or not page_host:
        return 0

    return int(
        action_host.lower() != page_host.lower()
    )


def has_external_form_action(soup, page_url):
    """
    Detects forms submitting data to external domains.
    """
    forms = soup.find_all("form")

    for form in forms:
        action = form.get("action", "")

        if is_external_action(action, page_url):
            return 1

    return 0


def count_external_links(soup, page_url):
    """
    Counts links that point to another domain.
    """
    page_host = urlparse(page_url).hostname

    if not page_host:
        return 0

    external_link_count = 0

    for link in soup.find_all("a", href=True):
        href = link.get("href")
        full_url = urljoin(page_url, href)

        link_host = urlparse(full_url).hostname

        if (
            link_host
            and link_host.lower() != page_host.lower()
        ):
            external_link_count += 1

    return external_link_count


def extract_dom_features(html, page_url):
    """
    Extracts HTML and DOM features.
    """
    if not html:
        return {
            "html_found": 0,
            "html_length": 0,
            "has_iframe": 0,
            "right_click_disabled": 0,
            "has_password_field": 0,
            "has_external_form_action": 0,
            "external_link_count": 0,
            "html_suspicious_word_count": 0,
            "html_suspicious_words": [],
        }

    soup = BeautifulSoup(html, "html.parser")

    visible_text = soup.get_text(
        " ",
        strip=True
    )

    suspicious_words = get_suspicious_words(
        html + " " + visible_text
    )

    return {
        "html_found": 1,
        "html_length": len(html),
        "has_iframe": has_iframe(soup),
        "right_click_disabled": is_right_click_disabled(html),
        "has_password_field": has_password_field(soup),
        "has_external_form_action": has_external_form_action(
            soup,
            page_url
        ),
        "external_link_count": count_external_links(
            soup,
            page_url
        ),
        "html_suspicious_word_count": len(suspicious_words),
        "html_suspicious_words": suspicious_words,
    }


def extract_features(url):
    """
    Compatibility adapter used by the combined API.

    Member 1's original module returns a rich nested analysis object. The
    group API needs a flat dictionary for the predictor, so this function
    preserves the rich data while exposing the field aliases used by the
    other contributions.
    """
    result = analyse_url(url)
    url_features = result["url_features"]
    dom_features = result["dom_features"]

    return {
        **url_features,
        **dom_features,
        "is_https": bool(url_features["has_https"]),
        "uses_shortening_service": bool(url_features["is_shortened_url"]),
        "has_suspicious_keyword": bool(
            url_features["suspicious_word_count"] > 0
        ),
        "num_at_symbols": url_features["has_at_symbol"],
        "num_subdomains": url_features["subdomain_count"],
        "external_form_action": bool(
            dom_features["has_external_form_action"]
        ),
        "risk_score_baseline": result["risk_score"],
        "baseline_verdict": result["verdict"],
        "analysed_url": result["analysed_url"],
        "html_source": result["source"],
        "reasons": result["reasons"],
    }


def calculate_risk_score(url_features, dom_features):
    """
    Calculates a basic risk score between 0 and 100.

    This is a rule-based baseline.
    It can later be replaced with an ML model.
    """
    score = 0
    reasons = []

    checks = [
        (
            url_features["url_length"] > 75,
            10,
            "URL is unusually long"
        ),
        (
            url_features["num_dots"] >= 4,
            8,
            "URL contains many dots"
        ),
        (
            url_features["num_hyphens"] >= 2,
            8,
            "URL contains multiple hyphens"
        ),
        (
            url_features["has_at_symbol"] == 1,
            20,
            "URL contains @ symbol"
        ),
        (
            url_features["has_ip_address"] == 1,
            20,
            "URL uses an IP address"
        ),
        (
            url_features["is_shortened_url"] == 1,
            10,
            "URL uses a shortening service"
        ),
        (
            url_features["has_https"] == 0,
            8,
            "URL does not use HTTPS"
        ),
        (
            url_features["suspicious_word_count"] >= 2,
            12,
            "URL contains suspicious words"
        ),
        (
            dom_features["has_iframe"] == 1,
            8,
            "Page contains an iframe"
        ),
        (
            dom_features["right_click_disabled"] == 1,
            5,
            "Page may disable right-click"
        ),
        (
            dom_features["has_password_field"] == 1,
            8,
            "Page contains a password field"
        ),
        (
            dom_features["has_external_form_action"] == 1,
            20,
            "Form submits data to another domain"
        ),
        (
            dom_features["html_suspicious_word_count"] >= 3,
            10,
            "HTML contains suspicious words"
        ),
    ]

    for condition, points, reason in checks:
        if condition:
            score += points
            reasons.append(reason)

    score = min(score, 100)

    if score >= 70:
        verdict = "high_risk"
    elif score >= 40:
        verdict = "suspicious"
    else:
        verdict = "low_risk"

    return score, verdict, reasons


def analyse_url(url, html_file=None):
    """
    Analyses one URL.

    If html_file is supplied, saved HTML is used.
    Otherwise, the live URL is downloaded.
    """
    original_url = url
    url = normalise_url(url)

    url_features = extract_url_features(url)

    if html_file:
        html = load_html_from_file(html_file)
        source = "saved_html_file"
    else:
        html = fetch_html(url)
        source = "live_url"

    dom_features = extract_dom_features(
        html,
        url
    )

    score, verdict, reasons = calculate_risk_score(
        url_features,
        dom_features
    )

    return {
        "input_url": original_url,
        "analysed_url": url,
        "source": source,
        "risk_score": score,
        "verdict": verdict,
        "reasons": reasons,
        "url_features": url_features,
        "dom_features": dom_features,
    }


def analyse_urls(urls):
    """
    Analyses one URL or many URLs.

    Examples:

    analyse_urls("https://example.com")

    analyse_urls([
        "https://example.com",
        "https://example.org"
    ])
    """
    if isinstance(urls, str):
        urls = [urls]

    return [
        analyse_url(url)
        for url in urls
    ]


if __name__ == "__main__":
    results = analyse_urls([
        "https://example.com",
        "https://example.org/login"
    ])

    for result in results:
        print(result)
