"""Pydantic request and response models for the PhishGuard API."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class URLRequest(BaseModel):
    url: str = Field(..., min_length=1, description="URL to analyze")


class BatchURLRequest(BaseModel):
    urls: List[str] = Field(..., min_length=1, max_length=200)


class AnalyzeResponse(BaseModel):
    url: str
    domain: Optional[str]
    verdict: str
    risk_score: float
    ml_probability: Optional[float]
    features: Dict[str, Any]
    threat_intel: Dict[str, Any]
    scan_id: Optional[int] = None
    model_source: Optional[str] = None


class HistoryItem(BaseModel):
    id: int
    url: str
    domain: Optional[str]
    verdict: str
    risk_score: float
    ml_probability: Optional[float]
    domain_age_days: Optional[int]
    ssl_valid: Optional[bool]
    blacklisted: Optional[bool]
    created_at: str