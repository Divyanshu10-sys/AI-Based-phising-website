"""PhishGuard API: feature extraction, prediction, threat intelligence, and history."""

from __future__ import annotations

import logging
import os
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

import database
import feature_extractor
import predictor
import threat_intel
from schemas import AnalyzeResponse, BatchURLRequest, HistoryItem, URLRequest

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("phishing-api")

app = FastAPI(
    title="PhishGuard API",
    description="AI-assisted phishing URL analysis with explainable fallback scoring.",
    version="2.0.0",
)

# Wildcard origins cannot be combined with credentialed CORS. The API does not
# use browser cookies, so credentials remain disabled for safe local demos.
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup() -> None:
    database.init_db()
    logger.info("Database ready at %s", database.DB_PATH)


def _parse_hostname(url: str) -> str:
    candidate = url if "://" in url else f"https://{url}"
    try:
        parsed = urlparse(candidate)
        hostname = parsed.hostname or ""
        # Accessing port forces urllib to validate malformed ports.
        _ = parsed.port
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid URL: {exc}") from exc
    if parsed.scheme not in {"http", "https"} or not hostname:
        raise HTTPException(
            status_code=400,
            detail="URL must include a valid http or https hostname",
        )
    return hostname


def compute_risk_score(
    ml_probability: float, features: dict, intel: dict
) -> float:
    """Combine ML, threat-intel, and strong feature signals into 0-100."""
    probability = max(0.0, min(1.0, ml_probability))
    score = probability * 60.0

    intel_points = 0.0
    if intel.get("blacklisted") is True:
        intel_points += 15.0
    if intel.get("ssl_valid") is False:
        intel_points += 5.0
    domain_age = intel.get("domain_age_days")
    if isinstance(domain_age, int) and domain_age < 90:
        intel_points += 5.0
    score += min(intel_points, 25.0)

    flag_points = 0.0
    if features.get("has_ip_address"):
        flag_points += 5.0
    if features.get("uses_shortening_service"):
        flag_points += 3.0
    if features.get("external_form_action"):
        flag_points += 4.0
    if features.get("has_password_field") and not features.get("is_https", True):
        flag_points += 3.0
    score += min(flag_points, 15.0)
    return round(min(max(score, 0.0), 100.0), 2)


def score_to_verdict(score: float) -> str:
    if score >= 70:
        return "phishing"
    if score >= 35:
        return "suspicious"
    return "safe"


def run_pipeline(url: str) -> dict:
    """Run one complete scan and persist its result."""
    if not isinstance(url, str) or not url.strip():
        raise HTTPException(status_code=400, detail="url must not be empty")
    hostname = _parse_hostname(url.strip())

    try:
        features = feature_extractor.extract_features(url.strip())
    except Exception as exc:
        logger.exception("feature extraction failed")
        raise HTTPException(
            status_code=502, detail=f"Feature extraction failed: {exc}"
        ) from exc

    try:
        prediction = predictor.predict(features)
    except Exception as exc:
        logger.exception("model prediction failed")
        raise HTTPException(
            status_code=502, detail=f"Model prediction failed: {exc}"
        ) from exc

    try:
        intel = threat_intel.get_intel(url.strip())
    except Exception as exc:
        logger.warning("threat intelligence failed: %s", exc)
        intel = {
            "domain": hostname,
            "domain_age_days": None,
            "ssl_valid": None,
            "blacklisted": None,
        }

    probability = float(prediction.get("probability", 0.0))
    risk_score = compute_risk_score(probability, features, intel)
    verdict = score_to_verdict(risk_score)
    scan_id = database.insert_scan(
        url=url.strip(),
        domain=intel.get("domain") or hostname,
        verdict=verdict,
        risk_score=risk_score,
        ml_probability=probability,
        domain_age_days=intel.get("domain_age_days"),
        ssl_valid=intel.get("ssl_valid"),
        blacklisted=intel.get("blacklisted"),
        features=features,
        intel=intel,
    )
    return {
        "url": url.strip(),
        "domain": intel.get("domain") or hostname,
        "verdict": verdict,
        "risk_score": risk_score,
        "ml_probability": probability,
        "features": features,
        "threat_intel": intel,
        "scan_id": scan_id,
        "model_source": prediction.get("model_source"),
    }


@app.get("/")
def root():
    return {"name": "PhishGuard API", "status": "ok", "version": app.version}


@app.get("/api/v1/health")
def health_check():
    return {"status": "ok"}


@app.post("/api/v1/analyze", response_model=AnalyzeResponse)
def analyze_url(payload: URLRequest):
    return run_pipeline(payload.url)


@app.post("/api/v1/analyze/batch")
def analyze_batch(payload: BatchURLRequest):
    if not payload.urls:
        raise HTTPException(status_code=400, detail="urls must not be empty")
    if len(payload.urls) > 200:
        raise HTTPException(status_code=400, detail="Max 200 URLs per batch request")
    results = []
    for url in payload.urls:
        try:
            results.append(run_pipeline(url))
        except HTTPException as exc:
            results.append({"url": url, "error": exc.detail})
    return {"count": len(results), "results": results}


@app.get("/api/v1/history", response_model=list[HistoryItem])
def get_history(
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    rows = database.get_history(limit=limit, offset=offset)
    for row in rows:
        for key in ("ssl_valid", "blacklisted"):
            if row[key] is not None:
                row[key] = bool(row[key])
    return rows


@app.get("/api/v1/analytics")
def get_analytics():
    return database.get_analytics()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", "8000")),
        reload=os.getenv("RELOAD", "false").lower() == "true",
    )