"""Best-effort domain, certificate, and optional VirusTotal intelligence.

All network-backed checks are optional and fail closed into explicit ``None``
signals instead of making a scan fail. Set ``VIRUSTOTAL_API_KEY`` to enable
the VirusTotal lookup; the service is still fully usable without it.
"""

from __future__ import annotations

import os
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests

try:
    import whois
except ImportError:  # pragma: no cover - optional dependency at runtime
    whois = None


def _hostname(url: str) -> str:
    parsed = urlparse(url if "://" in url else f"https://{url}")
    return (parsed.hostname or "").rstrip(".").lower()


def _normalise_creation_date(value):
    if isinstance(value, list):
        value = next((item for item in value if item is not None), None)
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def get_domain_age(url: str) -> dict:
    """Return WHOIS creation metadata, when a WHOIS server responds."""
    domain = _hostname(url)
    if not domain:
        return {"domain": None, "age_days": None, "error": "No hostname"}
    if whois is None:
        return {
            "domain": domain,
            "age_days": None,
            "error": "python-whois is not installed",
        }

    try:
        info = whois.whois(domain)
        creation_date = _normalise_creation_date(info.creation_date)
        if creation_date is None:
            return {
                "domain": domain,
                "age_days": None,
                "error": "No creation date found",
            }
        age_days = max(
            0, (datetime.now(timezone.utc) - creation_date).days
        )
        return {
            "domain": domain,
            "creation_date": creation_date.isoformat(),
            "age_days": age_days,
            "registrar": getattr(info, "registrar", None),
        }
    except Exception as exc:
        return {"domain": domain, "age_days": None, "error": str(exc)}


def check_ssl(url: str, timeout: float = 5.0) -> dict:
    """Inspect the certificate presented by the hostname on port 443."""
    domain = _hostname(url)
    result = {
        "domain": domain,
        "has_valid_ssl": None,
        "ssl_valid": None,
        "issuer": None,
        "ssl_issuer": None,
        "expires_on": None,
        "ssl_expires": None,
    }
    if not domain:
        result["error"] = "No hostname"
        return result

    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=timeout) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
        expires = datetime.strptime(
            cert["notAfter"], "%b %d %H:%M:%S %Y %Z"
        ).replace(tzinfo=timezone.utc)
        issuer_parts = dict(
            part for part in (entry[0] for entry in cert.get("issuer", []))
            if len(part) == 2
        )
        issuer = issuer_parts.get(
            "organizationName", issuer_parts.get("commonName", "Unknown")
        )
        valid = expires > datetime.now(timezone.utc)
        result.update(
            {
                "has_valid_ssl": valid,
                "ssl_valid": valid,
                "issuer": issuer,
                "ssl_issuer": issuer,
                "expires_on": expires.isoformat(),
                "ssl_expires": expires.isoformat(),
            }
        )
        return result
    except Exception as exc:
        result["has_valid_ssl"] = False
        result["ssl_valid"] = False
        result["error"] = str(exc)
        return result


def check_virustotal(url: str, api_key: str = "") -> dict:
    """Submit a URL to VirusTotal when an API key is configured."""
    if not api_key:
        return {
            "available": False,
            "malicious_votes": 0,
            "suspicious_votes": 0,
            "harmless_votes": 0,
            "error": "VIRUSTOTAL_API_KEY is not configured",
        }

    headers = {"x-apikey": api_key}
    try:
        submit = requests.post(
            "https://www.virustotal.com/api/v3/urls",
            headers=headers,
            data={"url": url},
            timeout=10,
        )
        submit.raise_for_status()
        analysis_id = submit.json()["data"]["id"]
        result = requests.get(
            f"https://www.virustotal.com/api/v3/analyses/{analysis_id}",
            headers=headers,
            timeout=10,
        )
        result.raise_for_status()
        stats = result.json()["data"]["attributes"].get("stats", {})
        return {
            "available": True,
            "malicious_votes": int(stats.get("malicious", 0)),
            "suspicious_votes": int(stats.get("suspicious", 0)),
            "harmless_votes": int(stats.get("harmless", 0)),
        }
    except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
        return {"available": False, "error": str(exc)}


def analyze_domain(url: str, virustotal_api_key: str = "") -> dict:
    """Return the original Member 3 shape plus normalized API fields."""
    age = get_domain_age(url)
    ssl_info = check_ssl(url)
    vt = check_virustotal(url, virustotal_api_key)
    malicious = vt.get("malicious_votes")
    return {
        "url": url,
        "domain": _hostname(url),
        "domain_age": age,
        "ssl_info": ssl_info,
        "threat_intel": vt,
        "domain_age_days": age.get("age_days"),
        "ssl_valid": ssl_info.get("ssl_valid"),
        "blacklisted": bool(malicious) if malicious is not None else None,
    }


def get_intel(url: str) -> dict:
    """Adapter expected by Member 4's combined API."""
    return analyze_domain(
        url, virustotal_api_key=os.getenv("VIRUSTOTAL_API_KEY", "")
    )


if __name__ == "__main__":
    import json

    print(json.dumps(get_intel("https://example.com"), indent=2, default=str))