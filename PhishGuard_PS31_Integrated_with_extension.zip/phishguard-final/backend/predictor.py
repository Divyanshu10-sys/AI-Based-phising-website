"""Model integration with a safe heuristic fallback.

Member 2's submitted JavaScript is a presentation generator rather than a
serialized classifier. This module therefore supports a future ``model.pkl``
or ``model.joblib`` without making the current demo depend on an absent model.
"""

from __future__ import annotations

import os
from numbers import Number

MODEL_PATH_CANDIDATES = ("model.joblib", "model.pkl")
_model = None
_model_load_attempted = False


def _try_load_model():
    global _model, _model_load_attempted
    if _model_load_attempted:
        return _model
    _model_load_attempted = True
    for name in MODEL_PATH_CANDIDATES:
        path = os.path.join(os.path.dirname(__file__), name)
        if not os.path.exists(path):
            continue
        try:
            import joblib

            _model = joblib.load(path)
            return _model
        except Exception:
            _model = None
    return None


def _heuristic_probability(features: dict) -> float:
    """Explainable baseline used until a trained model is supplied."""
    score = 0.0
    score += 0.25 if features.get("has_ip_address") else 0
    score += 0.15 if not features.get("is_https", True) else 0
    score += 0.15 if features.get("uses_shortening_service") else 0
    score += 0.15 if features.get("has_suspicious_keyword") else 0
    score += 0.10 if features.get("num_at_symbols", 0) > 0 else 0
    score += 0.10 if features.get("num_hyphens", 0) >= 3 else 0
    score += 0.10 if features.get("num_subdomains", 0) >= 3 else 0
    score += 0.10 if features.get("url_length", 0) > 75 else 0
    score += 0.10 if features.get("has_iframe") else 0
    score += 0.10 if features.get("right_click_disabled") else 0
    score += 0.15 if features.get("external_form_action") else 0
    score += 0.10 if features.get("has_password_field") else 0
    return max(0.0, min(1.0, score))


def _numeric_row(features: dict) -> dict:
    return {
        key: value
        for key, value in features.items()
        if isinstance(value, Number) and not isinstance(value, complex)
    }


def _model_probability(model, features: dict) -> float:
    import pandas as pd

    row = pd.DataFrame([_numeric_row(features)])
    feature_names = getattr(model, "feature_names_in_", None)
    if feature_names is not None:
        row = row.reindex(columns=list(feature_names), fill_value=0)
    probabilities = model.predict_proba(row)[0]
    classes = list(getattr(model, "classes_", range(len(probabilities))))
    phishing_index = next(
        (
            index
            for index, label in enumerate(classes)
            if str(label).lower() in {"1", "true", "phishing", "malicious"}
        ),
        min(1, len(probabilities) - 1),
    )
    return max(0.0, min(1.0, float(probabilities[phishing_index])))


def predict(features: dict) -> dict:
    """Return ``label``, probability, and model source for the API."""
    model = _try_load_model()
    if model is not None:
        try:
            probability = _model_probability(model, features)
            return {
                "label": "phishing" if probability >= 0.5 else "safe",
                "probability": probability,
                "model_source": "serialized_model",
            }
        except Exception:
            pass

    probability = _heuristic_probability(features)
    return {
        "label": "phishing" if probability >= 0.5 else "safe",
        "probability": probability,
        "model_source": "explainable_heuristic_fallback",
    }