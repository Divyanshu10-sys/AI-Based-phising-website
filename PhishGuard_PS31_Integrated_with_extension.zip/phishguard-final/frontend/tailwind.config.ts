import type { Config } from "tailwindcss";
const config: Config = { content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"], theme: { extend: { colors: { base: "#0A0E17", surface: "#111827" }, fontFamily: { display: ["var(--font-space-grotesk)"], sans: ["var(--font-inter)"], mono: ["var(--font-jetbrains-mono)"] } } }, plugins: [] };
export default config;
