# PhishGuard Frontend — Sumit

Frontend-only Next.js dashboard for the SIH phishing detection project.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Build check

```bash
npm run build
```

## Current status

The UI is fully wired to local deterministic mock data because the teammate's backend source/API contract was not included with the supplied file. The frontend is intentionally isolated from backend code.

When the FastAPI endpoint contract is available, replace the mock calls in `src/app/page.tsx` and `src/components/batch/BatchScanner.tsx` with `fetch()` calls and map the response to `src/types/index.ts`.
