import { BatchResultRow, DashboardStats, DailyScanStat, DomainAgeBucket, KeywordStat, RiskFactor, RiskLevel, ScanResult } from "@/types";
function riskLevelFromScore(score:number):RiskLevel { return score < 35 ? "safe" : score < 70 ? "suspicious" : "phishing"; }
export function generateMockScanResult(url:string):ScanResult {
 const seed=url.split("").reduce((a,c)=>a+c.charCodeAt(0),0); const score=Math.min(99,(seed*13)%100); const level=riskLevelFromScore(score);
 const domainAgeDays=level==="phishing"?2+(seed%10):level==="suspicious"?40+(seed%60):400+(seed%900); const sslValid=level!=="phishing";
 const factors:RiskFactor[]=[
  {label:"Domain Age",value:`${domainAgeDays} day${domainAgeDays===1?"":"s"}`,status:domainAgeDays<30?"phishing":domainAgeDays<180?"suspicious":"safe",weight:25},
  {label:"SSL Certificate",value:sslValid?"Valid, verified":"Invalid / self-signed",status:sslValid?"safe":"phishing",weight:20},
  {label:"ML Prediction",value:`${score}% phishing probability`,status:level,weight:35},
  {label:"URL Structure",value:level==="phishing"?"Suspicious subdomain nesting / IP-based host":"Standard structure",status:level==="phishing"?"phishing":"safe",weight:10},
  {label:"WHOIS Privacy",value:level==="safe"?"Public registrant":"Privacy-shielded registrant",status:level==="safe"?"safe":"suspicious",weight:10}
 ];
 return {id:globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${seed}`,url,domain:(url.match(/^(?:https?:\/\/)?([^/]+)/i)?.[1] ?? url),compositeScore:score,riskLevel:level,mlPrediction:{label:level==="phishing"?"Phishing":level==="suspicious"?"Suspicious":"Legitimate",confidence:score},factors,domainAgeDays,sslValid,timestamp:new Date().toISOString()};
}
export function generateMockBatchResults(urls:string[]):BatchResultRow[]{return urls.map(u=>{const r=generateMockScanResult(u);return {id:r.id,url:r.url,riskLevel:r.riskLevel,compositeScore:r.compositeScore,timestamp:r.timestamp};});}
export const mockDashboardStats:DashboardStats={totalScanned:18432,phishingBlocked:2116,activeThreats:47,avgRiskScore:31.6};
export const mockDailyScans:DailyScanStat[]=[{date:"Aug 10",scans:1820,phishing:210},{date:"Aug 11",scans:2043,phishing:268},{date:"Aug 12",scans:1790,phishing:190},{date:"Aug 13",scans:2310,phishing:340},{date:"Aug 14",scans:2670,phishing:402},{date:"Aug 15",scans:2210,phishing:288},{date:"Aug 16",scans:1950,phishing:231}];
export const mockTopKeywords:KeywordStat[]=[{keyword:"verify-account",count:342},{keyword:"secure-login",count:298},{keyword:"paypal-update",count:251},{keyword:"bank-alert",count:214},{keyword:"sbi-kyc",count:189},{keyword:"prize-claim",count:156},{keyword:"reset-password",count:132}];
export const mockDomainAgeDistribution:DomainAgeBucket[]=[{label:"< 1 month",value:38},{label:"1-6 months",value:27},{label:"6-12 months",value:15},{label:"> 1 year",value:20}];
export const sampleCsvUrls=["http://secure-paypal-verify-account.tk","https://www.google.com","http://sbi-kyc-update-portal.xyz","https://github.com","http://192.168.4.22/login/verify","https://www.wikipedia.org","http://bit.ly/3xR7fake","https://www.nseindia.com"];
