import { AnalyticsData, BatchResultRow, RiskFactor, RiskLevel, ScanResult } from "@/types";

const API_BASE = (process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000/api/v1").replace(/\/$/, "");

type ApiResponse = {
  scan_id: number;
  url: string;
  domain: string;
  verdict: RiskLevel;
  risk_score: number;
  ml_probability: number | null;
  model_source?: string;
  features: Record<string, unknown>;
  threat_intel: {
    domain_age_days?: number | null;
    ssl_valid?: boolean | null;
    blacklisted?: boolean | null;
  };
};

function factorStatus(value: RiskLevel): RiskLevel {
  return value;
}

function mapResult(payload: ApiResponse): ScanResult {
  const age = payload.threat_intel.domain_age_days ?? null;
  const ssl = payload.threat_intel.ssl_valid ?? null;
  const probability = Math.round((payload.ml_probability ?? 0) * 100);
  const urlStructure = payload.features.baseline_verdict === "high_risk"
    ? "phishing"
    : payload.features.baseline_verdict === "suspicious"
      ? "suspicious"
      : "safe";
  const factors: RiskFactor[] = [
    {
      label: "Domain Age",
      value: age === null ? "Unavailable" : `${age} day${age === 1 ? "" : "s"}`,
      status: age === null ? "suspicious" : age < 30 ? "phishing" : age < 180 ? "suspicious" : "safe",
      weight: 25,
    },
    {
      label: "SSL Certificate",
      value: ssl === true ? "Valid and verified" : ssl === false ? "Invalid or unavailable" : "Not checked",
      status: ssl === true ? "safe" : ssl === false ? "phishing" : "suspicious",
      weight: 20,
    },
    {
      label: "ML Prediction",
      value: `${probability}% phishing probability`,
      status: factorStatus(payload.verdict),
      weight: 35,
    },
    {
      label: "URL Structure",
      value: String(payload.features.reasons ?? "No strong lexical flags"),
      status: urlStructure,
      weight: 10,
    },
    {
      label: "Threat Intelligence",
      value: payload.threat_intel.blacklisted === true
        ? "Listed by threat intelligence"
        : payload.threat_intel.blacklisted === false
          ? "No malicious listing returned"
          : "Optional lookup unavailable",
      status: payload.threat_intel.blacklisted === true
        ? "phishing"
        : payload.threat_intel.blacklisted === false ? "safe" : "suspicious",
      weight: 10,
    },
  ];
  return {
    id: String(payload.scan_id),
    url: payload.url,
    domain: payload.domain,
    compositeScore: payload.risk_score,
    riskLevel: payload.verdict,
    mlPrediction: {
      label: payload.verdict === "phishing" ? "Phishing" : payload.verdict === "suspicious" ? "Suspicious" : "Legitimate",
      confidence: Math.max(probability, 100 - probability),
    },
    factors,
    domainAgeDays: age,
    sslValid: ssl,
    timestamp: new Date().toISOString(),
    modelSource: payload.model_source,
  };
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    cache: "no-store",
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(typeof body.detail === "string" ? body.detail : `API request failed (${response.status})`);
  }
  return body as T;
}

export async function analyzeUrl(url: string): Promise<ScanResult> {
  return mapResult(await request<ApiResponse>("/analyze", {
    method: "POST",
    body: JSON.stringify({ url }),
  }));
}

export async function analyzeBatch(urls: string[]): Promise<BatchResultRow[]> {
  const response = await request<{ results: Array<ApiResponse & { error?: string }> }>("/analyze/batch", {
    method: "POST",
    body: JSON.stringify({ urls }),
  });
  return response.results
    .filter((item) => !item.error)
    .map((item) => {
      const result = mapResult(item);
      return {
        id: result.id,
        url: result.url,
        riskLevel: result.riskLevel,
        compositeScore: result.compositeScore,
        timestamp: result.timestamp,
      };
    });
}

export async function getAnalytics(): Promise<AnalyticsData> {
  return request<AnalyticsData>("/analytics");
}