"use client";

import { useEffect, useMemo, useState } from "react";
import { Activity, BarChart3, Database, ShieldCheck, Upload } from "lucide-react";
import { motion } from "framer-motion";
import { analyzeUrl, getAnalytics } from "@/lib/api";
import { AnalyticsData, DashboardStats, ScanResult } from "@/types";
import { BatchScanner } from "@/components/batch/BatchScanner";
import { DomainAgeDonut } from "@/components/analytics/DomainAgeDonut";
import { KeywordsBarChart } from "@/components/analytics/KeywordsBarChart";
import { ScansLineChart } from "@/components/analytics/ScansLineChart";
import { StatCards } from "@/components/analytics/StatCards";
import { SummaryCard } from "@/components/scan/SummaryCard";
import { UrlSearchBar } from "@/components/scan/UrlSearchBar";

const EMPTY_ANALYTICS: AnalyticsData = {
  total_scans: 0,
  by_verdict: {},
  average_risk_score: 0,
  daily_scans: [],
  top_keywords: [],
  domain_age_distribution: [],
};

export default function Home() {
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData>(EMPTY_ANALYTICS);
  const [error, setError] = useState("");

  useEffect(() => {
    getAnalytics().then(setAnalytics).catch(() => {
      // The dashboard remains usable while the API is starting.
    });
  }, [result]);

  const stats: DashboardStats = useMemo(() => ({
    totalScanned: analytics.total_scans,
    phishingBlocked: analytics.by_verdict.phishing ?? 0,
    activeThreats: analytics.by_verdict.suspicious ?? 0,
    avgRiskScore: analytics.average_risk_score,
  }), [analytics]);

  const scan = async (url: string) => {
    setScanning(true);
    setResult(null);
    setError("");
    try {
      setResult(await analyzeUrl(url));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to scan this URL");
    } finally {
      setScanning(false);
    }
  };

  return (
    <main className="mx-auto max-w-6xl px-4 pb-24 pt-8 sm:px-6 lg:px-8">
      <header className="mb-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-6 w-6 text-cyan-400" />
          <span className="font-display text-lg font-bold">PhishGuard</span>
          <span className="rounded-full border border-slate-700 px-2 py-0.5 text-[10px] uppercase tracking-widest text-slate-500">
            PS-31
          </span>
        </div>
        <div className="hidden items-center gap-4 text-xs text-slate-500 sm:flex">
          <span className="flex items-center gap-1">
            <Activity className="h-3.5 w-3.5 text-emerald-400" /> API connected
          </span>
          <span>Threat analysis</span>
        </div>
      </header>

      <section className="text-center">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <p className="mb-3 font-mono text-xs uppercase tracking-[.3em] text-cyan-400">
            Real-time threat intelligence
          </p>
          <h1 className="font-display text-4xl font-bold sm:text-5xl">
            Is this URL <span className="text-cyan-400">safe?</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm text-slate-400">
            Analyze URL structure, explainable model signals, SSL status, and domain intelligence in one risk score.
          </p>
        </motion.div>
        <div className="mt-9">
          <UrlSearchBar onScan={scan} isScanning={scanning} />
        </div>
        {error && (
          <p className="mx-auto mt-5 max-w-2xl rounded-xl border border-red-400/30 bg-red-400/10 p-4 text-left text-sm text-red-300">
            {error}
          </p>
        )}
        {result && <SummaryCard result={result} />}
        <div className="mt-6 flex flex-wrap justify-center gap-3 text-[11px] text-slate-500">
          <span className="rounded-full border border-slate-800 px-3 py-1">Explainable ML fallback</span>
          <span className="rounded-full border border-slate-800 px-3 py-1">WHOIS</span>
          <span className="rounded-full border border-slate-800 px-3 py-1">SSL/TLS</span>
          <span className="rounded-full border border-slate-800 px-3 py-1">DOM features</span>
        </div>
      </section>

      <section className="mt-24">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-cyan-400" />
              <h2 className="font-display text-xl font-bold">Batch Scanner</h2>
            </div>
            <p className="mt-1 text-sm text-slate-400">Upload a CSV of URLs for bulk analysis.</p>
          </div>
        </div>
        <BatchScanner />
      </section>

      <section className="mt-24">
        <div className="mb-6 flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-cyan-400" />
          <div>
            <h2 className="font-display text-xl font-bold">Threat Analytics</h2>
            <p className="text-sm text-slate-400">Live aggregates from scans stored by the API.</p>
          </div>
        </div>
        <div className="space-y-6">
          <StatCards stats={stats} />
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <ScansLineChart data={analytics.daily_scans} />
            <KeywordsBarChart data={analytics.top_keywords} />
          </div>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <DomainAgeDonut data={analytics.domain_age_distribution} />
            <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6">
              <div className="flex items-center gap-3">
                <Database className="h-5 w-5 text-cyan-400" />
                <h3 className="font-semibold">Detection pipeline</h3>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-400">
                Every scan flows through URL and DOM features, the available model or explainable fallback, and optional domain intelligence before it is stored.
              </p>
              <div className="mt-5 rounded-xl border border-slate-800 bg-slate-950/60 p-4 font-mono text-xs text-slate-500">
                URL → Features → Prediction → Threat Intel → Risk Score
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="mt-20 border-t border-slate-800 pt-6 text-center text-xs text-slate-600">
        PhishGuard • KAVACH 2023 PS-31 • integrated group submission
      </footer>
    </main>
  );
}