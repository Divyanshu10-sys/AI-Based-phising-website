"use client";
import { useState } from "react";
import { analyzeBatch } from "@/lib/api";
import { BatchResultRow } from "@/types";
import { CsvDropzone } from "./CsvDropzone";
import { ResultsTable } from "./ResultsTable";
import { ScanProgress } from "./ScanProgress";

export function BatchScanner() {
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [results, setResults] = useState<BatchResultRow[]>([]);
  const [error, setError] = useState("");

  const handle = async (urls: string[]) => {
    if (!urls.length) return;
    setResults([]);
    setError("");
    setTotal(urls.length);
    setProgress(0);
    setScanning(true);
    try {
      const response = await analyzeBatch(urls);
      setResults(response);
      setProgress(urls.length);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Batch scan failed");
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="space-y-6">
      <CsvDropzone onFileAccepted={handle} />
      {scanning && <ScanProgress progress={progress} total={total} />}
      {error && <p className="rounded-xl border border-red-400/30 bg-red-400/10 p-4 text-sm text-red-300">{error}</p>}
      {!scanning && results.length > 0 && <ResultsTable rows={results} />}
    </div>
  );
}
