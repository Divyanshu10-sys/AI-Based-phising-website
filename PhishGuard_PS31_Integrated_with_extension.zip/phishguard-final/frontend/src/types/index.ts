export type RiskLevel = "safe" | "suspicious" | "phishing";
export interface RiskFactor { label:string; value:string; status:RiskLevel; weight:number; }
export interface ScanResult { id:string; url:string; domain:string; compositeScore:number; riskLevel:RiskLevel; mlPrediction:{label:string;confidence:number}; factors:RiskFactor[]; domainAgeDays:number|null; sslValid:boolean|null; timestamp:string; modelSource?:string; }
export interface BatchResultRow { id:string; url:string; riskLevel:RiskLevel; compositeScore:number; timestamp:string; }
export interface DailyScanStat { date:string; scans:number; phishing:number; }
export interface KeywordStat { keyword:string; count:number; }
export interface DomainAgeBucket { label:string; value:number; }
export interface DashboardStats { totalScanned:number; phishingBlocked:number; activeThreats:number; avgRiskScore:number; }
export interface AnalyticsData { total_scans:number; by_verdict:Record<string,number>; average_risk_score:number; daily_scans:DailyScanStat[]; top_keywords:KeywordStat[]; domain_age_distribution:DomainAgeBucket[]; }
