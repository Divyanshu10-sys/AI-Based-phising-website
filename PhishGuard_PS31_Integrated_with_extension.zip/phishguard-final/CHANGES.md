# Integration and bug-fix log

## Member 1 — Feature extractor

- Kept the full URL and DOM feature set instead of using Member 4's
  placeholder.
- Added `extract_features(url)` as the adapter expected by the combined API.
- Added the field aliases used by prediction and scoring
  (`is_https`, `uses_shortening_service`, `external_form_action`, and related
  names).
- Added empty-input handling and safe parsing for malformed ports.
- Made the public suffix extractor offline-safe so startup does not depend on
  downloading a suffix list.

## Member 2 — Presentation/model contribution

- Preserved the submitted `generate_presentation.js` and added a package
  script for generating the PPTX.
- Documented that this contribution generates presentation slides and does not
  include a trained model file.
- Hardened the API predictor so it can load `model.joblib`/`model.pkl` when
  added later, correctly identify a phishing class, and otherwise use a
  transparent heuristic fallback.

## Member 3 — Threat intelligence

- Replaced the placeholder API expected by Member 4 with a compatibility
  adapter named `get_intel(url)`.
- Normalized hostname parsing so paths, protocols, and trailing dots do not
  corrupt WHOIS or SSL lookups.
- Returned both the original detailed result shape and normalized fields:
  `domain_age_days`, `ssl_valid`, and `blacklisted`.
- Made missing WHOIS, invalid certificates, network failures, and absent
  VirusTotal configuration explicit and non-fatal.
- Moved VirusTotal configuration to the `VIRUSTOTAL_API_KEY` environment
  variable rather than source code.

## Member 4 — Backend and persistence

- Connected Member 1, Member 3, and the predictor through one working
  FastAPI pipeline.
- Fixed the invalid wildcard-CORS-plus-credentials combination.
- Added URL validation, batch validation, environment-configurable SQLite
  storage, UTC timestamps, and a root health response.
- Added live analytics for daily scans, verdict counts, domain age buckets,
  and suspicious keywords.

## Member 5 — Frontend

- Replaced deterministic mock scan results with calls to the FastAPI
  `/analyze` and `/analyze/batch` endpoints.
- Replaced mock analytics with the persisted `/analytics` response.
- Added API error states and model-source visibility in the result card.
- Kept the original dashboard presentation, CSV dropzone, charts, and risk
  gauge while wiring them to real data.

## Packaging

- Added one root README with run instructions.
- Added `.env.example` files without secrets.
- Retained the original uploaded ZIP files under `original_submissions/`.